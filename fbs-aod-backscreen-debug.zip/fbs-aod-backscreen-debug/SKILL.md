---
name: fbs-aod-backscreen-debug
agent_created: true
description: 调试 FBS (Flutter Back Screen) 在小米 HyperOS 折叠屏上的背屏 AOD 状态与通知转发问题。用于背屏 AOD 被破坏、前屏清除后背屏残留、display 1 电源控制等场景。
---

# FBS 背屏 AOD 调试指南

## 概述

本技能记录小米 HyperOS 折叠屏上背屏 AOD 状态调试的方法、已验证的命令和已知限制。核心问题是：第三方 Activity 一旦把 display 1 从 AOD/DOZE 拉到 ON，Activity 结束后无法从普通应用层恢复 AOD 暗屏。

## 适用场景

- 背屏 AOD 状态被通知转发破坏
- 前屏通知清除后，背屏通知仍然残留
- 背屏无法点亮 / display 1 状态异常
- 背屏 AOD 与 Activity 切换的调试

## 快速诊断命令

```bash
# 查看 display 1 状态
adb shell cmd display get-displays | grep -E 'Display id 1|state|canHostTasks'

# 查看 display 1 当前亮度/电源状态
adb shell dumpsys display | grep -A 20 'DisplayDevice.*display 1\|Display 1'

# 查看 FBS 相关日志
adb logcat -s BackScreenController BackScreenNotif FBSNotificationListener -v time
```

## 常用恢复命令

```bash
# 背屏无法点亮时尝试恢复
adb shell "cmd display enable-display 1 && cmd display power-reset 1 && input -d 1 keyevent KEYCODE_WAKEUP"
```

## 已尝试的 AOD 恢复方法

| 方法 | 效果 | 副作用 |
|------|------|--------|
| `input -d 1 keyevent KEYCODE_WAKEUP` | 可唤醒背屏 | 无 |
| `input -d 1 keyevent 26` / `KEYCODE_SLEEP` | 可关闭背屏 | 影响正面屏幕 |
| `cmd display power-reset 1` | 背屏回到壁纸时钟亮屏 | 无法回到 AOD 暗屏 |
| `cmd display power-off 1; power-reset 1` | 背屏黑屏后回到壁纸时钟亮屏 | 无法回到 AOD 暗屏 |
| `cmd display disable-display 1; enable-display 1` | 风险高，可能导致背屏无法点亮 | 不建议 |
| `am broadcast -a miui.intent.action.SUB_SCREEN_OFF` | 失败 | protected broadcast，shell 无法发送 |

## 已知限制

- 第三方应用无法发送小米 protected broadcast (`miui.intent.action.SUB_SCREEN_ON/OFF`)，因此无法直接触发 subscreencenter 回到 AOD 模式。
- `cmd display` 只能控制 display 1 的电源状态（ON/OFF），无法直接将其设置为 DOZE/AOD 状态。
- AOD 暗屏恢复需要 subscreencenter 系统服务重新进入 AOD 渲染，这需要 root / platform 签名 / 系统级权限。

## 推荐实现策略

1. **通知转发**：启动 Activity 到 display 1，正常亮屏显示通知。
2. **5 秒 AOD 过渡**：Activity 启动 5 秒后降低 `screenBrightness` 到 `0.01f`，清除 `FLAG_KEEP_SCREEN_ON`，保持通知内容但模拟 AOD 暗屏。
3. **清除通知**：直接 finish Activity，不强制操作 display 1 电源，让系统接管显示壁纸时钟（亮屏）。
4. **避免破坏**：AOD 期间不 `force-stop` subscreencenter，不 restore subscreencenter，避免 SECONDARY_HOME 选择对话框。

## 相关代码位置

- `android/app/src/main/kotlin/com/example/fbs/service/BackScreenController.kt`
- `android/app/src/main/kotlin/com/example/fbs/service/BackScreenNotificationActivity.kt`
- `android/app/src/main/kotlin/com/example/fbs/service/FBSNotificationListenerService.kt`

## 参考资料

- `references/back_screen_analysis.md` - 官方背屏应用逆向分析

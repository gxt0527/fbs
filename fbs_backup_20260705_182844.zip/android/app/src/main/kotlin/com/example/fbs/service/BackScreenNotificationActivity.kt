package com.example.fbs.service

import android.app.Activity
import android.graphics.*
import android.os.*
import android.util.Log
import android.view.View
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.*

/**
 * 背屏通知渲染 Activity — 运行在 display 1
 *
 * 由 BackScreenController 通过 am start --display 1 启动，
 * 使用 Canvas 自定义绘制通知内容。
 * 所有样式参数通过 Intent extras 传递。
 */
class BackScreenNotificationActivity : Activity() {

    companion object {
        private const val TAG = "BackScreenNotif"
    }

    private var dismissHandler = Handler(Looper.getMainLooper())
    private var displayDurationMs = 10000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            Log.d(TAG, "onCreate start, display=${display?.displayId}")

            // ── 全屏设置：跟随系统亮度，不要强制唤醒（避免亮屏闪烁） ──
            try {
                window.addFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                    or WindowManager.LayoutParams.FLAG_FULLSCREEN
                    or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                )
                // -1 = 跟随系统亮度（AOD 模式自适性）
                val lp = window.attributes
                lp.screenBrightness = -1.0f
                window.attributes = lp
            } catch (e: Exception) {
                Log.w(TAG, "Window flags error: ${e.message}")
            }

            // ── 解析 Intent extras ──
            val title = intent.getStringExtra("title") ?: ""
            val subtitle = intent.getStringExtra("subtitle") ?: ""
            val content = intent.getStringExtra("content") ?: ""
            val appName = intent.getStringExtra("appName") ?: ""

            val titleFontSize = intent.getStringExtra("titleFontSize")?.toFloatOrNull() ?: 28f
            val subtitleFontSize = intent.getStringExtra("subtitleFontSize")?.toFloatOrNull() ?: 20f
            val contentFontSize = intent.getStringExtra("contentFontSize")?.toFloatOrNull() ?: 16f

            val titleColor = parseColorExtra("titleColor", Color.WHITE)
            val subtitleColor = parseColorExtra("subtitleColor", Color.parseColor("#B0B0B0"))
            val contentColor = parseColorExtra("contentColor", Color.parseColor("#E0E0E0"))
            val backgroundColor = parseColorExtra("backgroundColor", Color.parseColor("#1A1A2E"))

            val showAppIcon = intent.getStringExtra("showAppIcon")?.toBooleanStrictOrNull() ?: true
            val showTimestamp = intent.getStringExtra("showTimestamp")?.toBooleanStrictOrNull() ?: true
            val padding = intent.getStringExtra("padding")?.toFloatOrNull() ?: 24f
            val spacing = intent.getStringExtra("spacing")?.toFloatOrNull() ?: 12f
            displayDurationMs = intent.getStringExtra("displayDurationMs")?.toLongOrNull() ?: 10000L

            Log.d(TAG, "Parsed: title=$title, subtitle=$subtitle, content=${content.take(30)}, "
                + "w=$titleFontSize, h=$subtitleFontSize, c=$contentFontSize, "
                + "bg=#$backgroundColor, dur=$displayDurationMs")

            // ── 创建渲染 View ──
            renderView = NotificationRenderView(
                context = this,
                config = RenderConfig(
                    title = if (title.isNotEmpty()) title else appName,
                    subtitle = subtitle,
                    content = content,
                    titleFontSize = titleFontSize,
                    subtitleFontSize = subtitleFontSize,
                    contentFontSize = contentFontSize,
                    titleColor = titleColor,
                    subtitleColor = subtitleColor,
                    contentColor = contentColor,
                    backgroundColor = backgroundColor,
                    showAppIcon = showAppIcon,
                    showTimestamp = showTimestamp,
                    padding = padding,
                    spacing = spacing,
                )
            )
            renderView?.setBackgroundColor(backgroundColor)

            setContentView(renderView)
            Log.d(TAG, "setContentView done")

            // 不拦截触摸 — 让双击等手势穿透到系统（TouchInteractionService）
            renderView?.isClickable = false
            renderView?.isFocusable = false

            // ── 自动消失 ──
            dismissHandler.postDelayed({
                Log.d(TAG, "Auto-dismiss after ${displayDurationMs}ms")
                finish()
            }, displayDurationMs)

            Log.d(TAG, "onCreate complete")

        } catch (e: Exception) {
            Log.e(TAG, "onCreate failed", e)
            finish()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d(TAG, "onConfigChanged: w=${newConfig.screenWidthDp}dp h=${newConfig.screenHeightDp}dp d=${newConfig.densityDpi} display=${display?.displayId}")
        // 移屏后强制让 View 重新布局和绘制
        renderView?.requestLayout()
        renderView?.invalidate()
    }

    private var renderView: NotificationRenderView? = null

    override fun onDestroy() {
        dismissHandler.removeCallbacksAndMessages(null)
        Log.d(TAG, "onDestroy")
        super.onDestroy()
    }

    private fun parseColorExtra(key: String, default: Int): Int {
        val hex = intent.getStringExtra(key) ?: return default
        return try {
            val clean = hex.replace("#", "")
            if (clean.length == 6) Color.parseColor("#$clean")
            else if (clean.length == 8) Color.parseColor("#${clean.substring(2)}")
            else default
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse color $key=$hex: ${e.message}")
            default
        }
    }

    // ═══════════════════════════════════════════
    // 渲染配置
    // ═══════════════════════════════════════════

    data class RenderConfig(
        val title: String,
        val subtitle: String,
        val content: String,
        val titleFontSize: Float,
        val subtitleFontSize: Float,
        val contentFontSize: Float,
        val titleColor: Int,
        val subtitleColor: Int,
        val contentColor: Int,
        val backgroundColor: Int,
        val showAppIcon: Boolean,
        val showTimestamp: Boolean,
        val padding: Float,
        val spacing: Float,
    )

    // ═══════════════════════════════════════════
    // 自定义渲染 View
    // ═══════════════════════════════════════════

    class NotificationRenderView(
        context: android.content.Context,
        private val config: RenderConfig,
    ) : View(context) {

        private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = config.titleColor
            textSize = config.titleFontSize
            typeface = Typeface.DEFAULT_BOLD
        }
        private val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = config.subtitleColor
            textSize = config.subtitleFontSize
        }
        private val contentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = config.contentColor
            textSize = config.contentFontSize
        }
        private val timestampPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (config.contentColor and 0x00FFFFFF) or 0x80000000.toInt()
            textSize = config.contentFontSize * 0.65f
        }
        private val bgPaint = Paint().apply {
            color = config.backgroundColor
            style = Paint.Style.FILL
        }
        private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (config.titleColor and 0x00FFFFFF) or 0x33000000
            style = Paint.Style.FILL
        }
        private val iconBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (config.titleColor and 0x00FFFFFF) or 0x40000000
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0 || h <= 0) return

            android.util.Log.d("BackScreenNotif", "onDraw: ${w}x${h}, title=${config.title.take(20)}, titleColor=#${Integer.toHexString(config.titleColor)}, bgColor=#${Integer.toHexString(config.backgroundColor)}")

            val p = config.padding
            val s = config.spacing

            // ── 背景 ──
            canvas.drawRect(0f, 0f, w, h, bgPaint)

            var y = p

            // ── 标题行 ──
            val iconSize = config.titleFontSize + 8f
            val iconRadius = iconSize * 0.22f

            if (config.showAppIcon) {
                val iconLeft = p
                val iconTop = y
                val iconRect = RectF(iconLeft, iconTop, iconLeft + iconSize, iconTop + iconSize)
                canvas.drawRoundRect(iconRect, iconRadius, iconRadius, iconPaint)
                canvas.drawRoundRect(iconRect, iconRadius, iconRadius, iconBorderPaint)

                val titleX = iconLeft + iconSize + s * 0.7f
                val titleBaseline = y + iconSize / 2f + (config.titleFontSize / 2.5f)
                canvas.drawText(config.title, titleX, titleBaseline, titlePaint)
                y += iconSize + s
            } else {
                canvas.drawText(config.title, p, y + config.titleFontSize, titlePaint)
                y += config.titleFontSize + s
            }

            // ── 副标题 ──
            if (config.subtitle.isNotEmpty()) {
                canvas.drawText(config.subtitle, p, y + config.subtitleFontSize, subtitlePaint)
                y += config.subtitleFontSize + s
            }

            // ── 正文 ──
            val maxWidth = w - p * 2
            val contentText = fitText(config.content, contentPaint, maxWidth, h - y - p)
            canvas.drawText(contentText, p, y + config.contentFontSize, contentPaint)

            // ── 时间戳 ──
            if (config.showTimestamp) {
                val now = timeFormat.format(Date())
                val timeTextWidth = timestampPaint.measureText(now)
                canvas.drawText(now, w - p - timeTextWidth, h - p, timestampPaint)
            }
        }

        private fun fitText(text: String, paint: Paint, maxWidth: Float, maxHeight: Float): String {
            if (text.isEmpty()) return text
            if (paint.measureText(text) <= maxWidth) return text

            var truncated = text
            while (truncated.length > 1 && paint.measureText("$truncated…") > maxWidth) {
                truncated = truncated.substring(0, truncated.length - 1)
            }
            return "$truncated…"
        }
    }
}

"""备份 FBS 项目代码到 zip，排除构建产物和缓存"""
import zipfile, os, datetime

src = r'D:\MSRR\fbs'
timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
dst = f'{src}/fbs_backup_{timestamp}.zip'

# 要排除的一级目录名
exclude_dirs = {
    'build', '.dart_tool', '.gradle', '.idea', '.vscode', '__pycache__', '.git',
    'tmp_apk_extract', 'tmp_install', 'tmp_pronto', 'tmp_scene', 'tmp_sdk',
    '.pub-cache',
}
# 要排除的扩展名
exclude_ext = {'.class', '.log', '.lock', '.zip'}
# 要排除的特定文件
exclude_files = {'.packages', 'pubspec.lock'}

count = 0
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(src):
        # 剪枝：跳过排除目录
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in exclude_ext or f in exclude_files:
                continue
            full = os.path.join(root, f)
            arcname = os.path.relpath(full, src)
            zf.write(full, arcname)
            count += 1

size_mb = os.path.getsize(dst) / (1024 * 1024)
print(f'备份完成！')
print(f'路径: {dst}')
print(f'文件数: {count}')
print(f'大小: {size_mb:.1f} MB')
